module.exports = {

"[project]/src/features/fields/components/field-tables/index.tsx [app-ssr] (ecmascript, next/dynamic entry, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/src_ad60ffae._.js",
  "server/chunks/ssr/node_modules_@tanstack_table-core_build_lib_index_mjs_81b618fe._.js",
  "server/chunks/ssr/node_modules_@radix-ui_react-icons_dist_react-icons_esm_305d8165.js",
  "server/chunks/ssr/node_modules_date-fns_26e014d0._.js",
  "server/chunks/ssr/node_modules_react-day-picker_dist_index_esm_1f49298b.js",
  "server/chunks/ssr/node_modules_zod_lib_index_mjs_f9af4762._.js",
  "server/chunks/ssr/node_modules_57a9f39d._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/features/fields/components/field-tables/index.tsx [app-ssr] (ecmascript, next/dynamic entry)");
    });
});
}}),
"[project]/src/features/fields/components/field-tables/columns.tsx [app-ssr] (ecmascript, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/src_features_fields_components_field-tables_cell-action_tsx_8cb09744._.js",
  "server/chunks/ssr/_6c20ceae._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/features/fields/components/field-tables/columns.tsx [app-ssr] (ecmascript)");
    });
});
}}),

};