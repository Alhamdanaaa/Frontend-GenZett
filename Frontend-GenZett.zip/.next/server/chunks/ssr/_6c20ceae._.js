module.exports = {

"[project]/src/features/fields/components/field-tables/columns.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "getColumns": (()=>getColumns)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Text$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/text.js [app-ssr] (ecmascript) <export default as Text>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/shared/lib/app-dynamic.js [app-ssr] (ecmascript)");
;
'use client';
;
;
;
const CellAction = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.r("[project]/src/features/fields/components/field-tables/cell-action.tsx [app-ssr] (ecmascript, next/dynamic entry, async loader)")(__turbopack_context__.i).then((mod)=>mod.CellAction), {
    loadableGenerated: {
        modules: [
            "[project]/src/features/fields/components/field-tables/cell-action.tsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false
});
function getColumns(locationOptions, sportOptions) {
    return [
        {
            id: 'name',
            accessorKey: 'name',
            header: 'Nama Lapangan',
            cell: ({ cell })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    children: cell.getValue()
                }, void 0, false, {
                    fileName: "[project]/src/features/fields/components/field-tables/columns.tsx",
                    lineNumber: 19,
                    columnNumber: 27
                }, this),
            meta: {
                label: 'Nama Lapangan',
                placeholder: 'Cari...',
                variant: 'text',
                icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Text$3e$__["Text"]
            },
            enableColumnFilter: true
        },
        {
            id: 'location',
            accessorKey: 'location',
            header: 'Lokasi Cabang',
            cell: ({ cell })=>{
                const location = cell.getValue();
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    children: location
                }, void 0, false, {
                    fileName: "[project]/src/features/fields/components/field-tables/columns.tsx",
                    lineNumber: 34,
                    columnNumber: 16
                }, this);
            },
            enableColumnFilter: true,
            meta: {
                label: 'Lokasi Cabang',
                variant: 'select',
                options: locationOptions
            }
        },
        {
            id: 'sport',
            accessorKey: 'sport',
            header: 'Cabang Olahraga',
            cell: ({ cell })=>{
                const sport = cell.getValue();
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    children: sport
                }, void 0, false, {
                    fileName: "[project]/src/features/fields/components/field-tables/columns.tsx",
                    lineNumber: 49,
                    columnNumber: 16
                }, this);
            },
            enableColumnFilter: true,
            meta: {
                label: 'Cabang Olahraga',
                variant: 'select',
                options: sportOptions
            }
        },
        {
            accessorKey: 'jamMulai',
            header: 'Jam Operasi',
            cell: ({ row })=>{
                const jamMulai = row.original.startHour;
                const jamTutup = row.original.endHour;
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    children: [
                        jamMulai?.slice(0, 5),
                        " - ",
                        jamTutup?.slice(0, 5)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/features/fields/components/field-tables/columns.tsx",
                    lineNumber: 64,
                    columnNumber: 16
                }, this);
            }
        },
        {
            id: 'actions',
            cell: ({ row })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(CellAction, {
                    data: row.original
                }, void 0, false, {
                    fileName: "[project]/src/features/fields/components/field-tables/columns.tsx",
                    lineNumber: 69,
                    columnNumber: 26
                }, this)
        }
    ];
}
}}),
"[project]/node_modules/lucide-react/dist/esm/icons/text.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
/**
 * @license lucide-react v0.476.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ __turbopack_context__.s({
    "__iconNode": (()=>__iconNode),
    "default": (()=>Text)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-ssr] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M17 6.1H3",
            key: "wptmhv"
        }
    ],
    [
        "path",
        {
            d: "M21 12.1H3",
            key: "1j38uz"
        }
    ],
    [
        "path",
        {
            d: "M15.1 18H3",
            key: "1nb16a"
        }
    ]
];
const Text = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])("Text", __iconNode);
;
 //# sourceMappingURL=text.js.map
}}),
"[project]/node_modules/lucide-react/dist/esm/icons/text.js [app-ssr] (ecmascript) <export default as Text>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Text": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/text.js [app-ssr] (ecmascript)");
}}),

};

//# sourceMappingURL=_6c20ceae._.js.map