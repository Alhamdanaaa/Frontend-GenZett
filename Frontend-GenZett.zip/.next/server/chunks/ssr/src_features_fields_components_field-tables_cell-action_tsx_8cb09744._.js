module.exports = {

"[project]/src/features/fields/components/field-tables/cell-action.tsx [app-ssr] (ecmascript, next/dynamic entry, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/src_features_fields_components_field-detail-dialog_tsx_8ac0c6ea._.js",
  "server/chunks/ssr/_d7c5d2b9._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/features/fields/components/field-tables/cell-action.tsx [app-ssr] (ecmascript, next/dynamic entry)");
    });
});
}}),

};