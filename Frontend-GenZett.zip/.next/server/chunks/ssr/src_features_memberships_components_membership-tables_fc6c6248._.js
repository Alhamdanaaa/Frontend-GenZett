module.exports = {

"[project]/src/features/memberships/components/membership-tables/index.tsx [app-ssr] (ecmascript, next/dynamic entry, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/src_19eecc7b._.js",
  "server/chunks/ssr/node_modules_746e8e60._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/features/memberships/components/membership-tables/index.tsx [app-ssr] (ecmascript, next/dynamic entry)");
    });
});
}}),
"[project]/src/features/memberships/components/membership-tables/cell-action.tsx [app-ssr] (ecmascript, next/dynamic entry, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/_0b9885d8._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/features/memberships/components/membership-tables/cell-action.tsx [app-ssr] (ecmascript, next/dynamic entry)");
    });
});
}}),

};