module.exports = {

"[project]/src/features/fields/components/field-detail-dialog.tsx [app-ssr] (ecmascript, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/src_features_fields_components_field-detail-dialog_tsx_0038b542._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/features/fields/components/field-detail-dialog.tsx [app-ssr] (ecmascript)");
    });
});
}}),

};