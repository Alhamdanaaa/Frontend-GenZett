module.exports = {

"[project]/src/features/memberships/components/membership-tables/columns.tsx [app-rsc] (ecmascript, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/src_features_memberships_components_membership-tables_columns_tsx_dad9e87e._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/features/memberships/components/membership-tables/columns.tsx [app-rsc] (ecmascript)");
    });
});
}}),

};